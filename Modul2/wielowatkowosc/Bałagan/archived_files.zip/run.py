import main as main_program

main_program.sample_txt_file()